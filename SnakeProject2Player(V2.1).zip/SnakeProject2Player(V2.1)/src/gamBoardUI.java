import javax.swing.*;

class gameBoardUI extends JPanel {

    private ImageIcon titleImage;
    private ImageIcon appleImage;
    private ImageIcon snakeimage;
    private ImageIcon muscleImage;	// image for muscle powerup
    private ImageIcon poisonImage;	// image for poison powerup
}
